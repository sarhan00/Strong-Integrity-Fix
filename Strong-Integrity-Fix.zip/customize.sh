# Allow a scripts-only mode for older 
ui_print " "
ui_print "╔═══════════════════════════════════════════════════╗"
ui_print "║                🎊 Welcome 🎊                     ║"
ui_print "║          Made with Love ♥️ by SarhanRoot         ║"
ui_print "╚═══════════════════════════════════════════════════╝"
ui_print " "

ui_print "╔═══════════════════════════════════════════════════╗"
ui_print "║                  🔥 UPDATE 🔥                    ║"
ui_print "╠═══════════════════════════════════════════════════╣"
ui_print "║  • Play Strong Integrity API                     ║"
ui_print "║  • Enhanced Performance                          ║"
ui_print "║  • Improved Stability                            ║"
ui_print "║                                                   ║"
ui_print "║             ┏━━━━━━━━━━━━━━━━┓                   ║"
ui_print "║             ┃    👑 SARHANROOT 👑    ┃           ║"
ui_print "║             ┗━━━━━━━━━━━━━━━━┛                   ║"
ui_print "╠═══════════════════════════════════════════════════╣"
ui_print "║              📞 Contact Info                     ║"
ui_print "║  • 📩 Telegram: @sarhanhassan                   ║"
ui_print "║  • 👨‍💻 Developer: @SarhanRoot                    ║"
ui_print "║  • 🔗 Channel: t.me/sarhanhassan                ║"
ui_print "╚═══════════════════════════════════════════════════╝"
ui_print " "

# ---------- Cleanup Tricky Store (run as root) ----------
su -c "rm -rf /data/adb/modules/strongIntegrtiyfix
rm -f /data/adb/boot_hash
rm -rf /data/adb/tricky_store && mkdir -p /data/adb/tricky_store && chmod 700 /data/adb/tricky_store"

#!/system/bin/sh
# 🔹 SET_TARGET

log_message() {
    echo "$(date +%Y-%m-%d\ %H:%M:%S) [SET_TARGET] $1"
}
log_message "Start"

t='/data/adb/tricky_store/target.txt'
tees='/data/adb/tricky_store/tee_status'

# tee status 
teeBroken="false"
if [ -f "$tees" ]; then
    teeBroken=$(grep -E '^teeBroken=' "$tees" | cut -d '=' -f2 2>/dev/null || echo "false")
fi

# add list special (بدون علامة تعجب)
echo "android" >> "$t"
echo "com.android.vending" >> "$t"
echo "com.google.android.gsf" >> "$t"
echo "com.google.android.gms" >> "$t"
echo "com.google.android.apps.walletnfcrel" >> "$t"
echo "com.openai.chatgpt" >> "$t"
echo "com.reveny.nativecheck" >> "$t"
echo "io.github.vvb2060.keyattestation" >> "$t"
echo "io.github.vvb2060.mahoshojo" >> "$t"
echo "icu.nullptr.nativetest" >> "$t"
echo "com.android.nativetest" >> "$t"
echo "io.liankong.riskdetector" >> "$t"
echo "me.garfieldhan.holmes" >> "$t"
echo "luna.safe.luna" >> "$t"
echo "com.zhenxi.hunter" >> "$t"
echo "gr.nikolasspyr.integritycheck" >> "$t"
echo "com.youhu.laifu" >> "$t"
echo "com.google.android.contactkeys" >> "$t"
echo "com.google.android.ims" >> "$t"
echo "com.google.android.safetycore" >> "$t"
echo "com.whatsapp" >> "$t"
echo "com.whatsapp.w4b" >> "$t"

# add list
log_message "Writing"
add_packages() {
    pm list packages "$1" | cut -d ":" -f 2 | while read -r pkg; do
        if [ -n "$pkg" ] && ! grep -q "^$pkg" "$t"; then
            if [ "$teeBroken" = "true" ]; then
                echo "$pkg!" >> "$t"
            else
                echo "$pkg" >> "$t"
            fi
        fi
    done
}

# add user apps
add_packages "-3"

# add system apps
add_packages "-s"

log_message "Finish"



# 🔹 SET_SECURITY_PATCH

log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') [SET_SECURITY_PATCH] $1"
}
log_message "Start"

sp="/data/adb/tricky_store/security_patch.txt"

log_message "Counting"
current_year=$(date +%Y)
current_month=$(date +%m)

if [ "$current_month" -eq 1 ]; then
  prev_month=12
  prev_year=$((current_year - 1))
else
  prev_month=$((10#$current_month - 1))
  prev_year=$current_year
fi

log_message "Writing"
formatted_month=$(printf "%02d" $prev_month)
echo "all=${prev_year}-${formatted_month}-05" > "$sp"
log_message "Finish"



# 🔹 SET_BOOT_HASH

log_message() {
    echo "$(date +%Y-%m-%d\ %H:%M:%S) [SET_BOOT_HASH] $1"
}
log_message "Start"

boot_hash=$(su -c "getprop ro.boot.vbmeta.digest")
file_path="/data/adb/boot_hash"

mkdir -p "$(dirname "$file_path")"

if [ -n "$boot_hash" ]; then
    log_message "Writing"
    echo "$boot_hash" > "$file_path"
    chmod 644 "$file_path"
    su -c "resetprop -n ro.boot.vbmeta.digest $boot_hash"
    log_message "Finish"
else
    log_message "Boot hash not found (vbmeta digest is empty)"
fi



# 🔹 KILL_GOOGLE + REMOVE_YURIKEY

log_message() {
    echo "$(date +%Y-%m-%d\ %H:%M:%S) [KILL_GOOGLE] $1"
}

log_message "Start"
log_message "Writing"

PKGS="com.android.vending"
for pkg in $PKGS; do
    am force-stop "$pkg" >/dev/null 2>&1
    pm clear "$pkg" >/dev/null 2>&1
done

# حذف مسار Yurikey
rm -rf /data/adb/modules/Yurikey
cp -f "$MODPATH/zygisk/keybox.xml" /data/adb/tricky_store/

# 🔹 DELETE_TWRP_FOLDER

echo "Starting deletion of TWRP folder..."
TWRP_FOLDER="/sdcard/TWRP"

if [ -d "$TWRP_FOLDER" ]; then
  echo "- Found folder $TWRP_FOLDER. Deleting..."
  rm -rf "$TWRP_FOLDER"
  echo "Folder deleted successfully."
else
  echo "- Folder $TWRP_FOLDER not found. Nothing to delete."
fi

echo "TWRP folder deletion script completed."



# 🔹 HIDE_MY_APPLIST FIX

echo "Starting fix for Hide My Applist (HMA)..."
echo "Searching for suspicious folders..."

FOLDERS=$(find /data/system -maxdepth 1 -type d \( -iname "*hide*" -o -iname "*hma*" -o -iname "*applist*" \) 2>/dev/null)

if [ -z "$FOLDERS" ]; then
  echo "No HideMyApplist-related folder found. Nothing to delete."
else
  for FOLDER in $FOLDERS; do
    echo "Deleting folder: $FOLDER ..."
    rm -rf "$FOLDER"
    echo "Folder deleted: $FOLDER"
  done
fi

echo "Hide My Applist (HMA) fix completed."
log_message "Finish"
#1

if [ -f /data/adb/modules/playintegrityfix/scripts-only-mode ]; then
    ui_print "! Installing global scripts only; Zygisk attestation fallback and device spoofing disabled"
    touch $MODPATH/scripts-only-mode
    sed -i 's/\(description=\)\(.*\)/\1[Scripts-only mode] \2/' $MODPATH/module.prop
    [ -f /data/adb/modules/playintegrityfix/uninstall.sh ] && sh /data/adb/modules/playintegrityfix/uninstall.sh
    rm -rf $MODPATH/action.sh $MODPATH/autopif2.sh $MODPATH/classes.dex $MODPATH/common_setup.sh \
        $MODPATH/custom.pif.json $MODPATH/example.app_replace.list $MODPATH/example.pif.json \
        $MODPATH/migrate.sh $MODPATH/pif.json $MODPATH/zygisk \
        /data/adb/modules/playintegrityfix/custom.app_replace.list \
        /data/adb/modules/playintegrityfix/custom.pif.json \
        /data/adb/modules/playintegrityfix/system \
        /data/adb/modules/playintegrityfix/uninstall.sh
fi

# Copy any disabled app files to updated module
if [ -d /data/adb/modules/playintegrityfix/system ]; then
    ui_print "- Restoring disabled ROM apps configuration"
    cp -afL /data/adb/modules/playintegrityfix/system $MODPATH
fi

# Copy any supported custom files to updated module
for FILE in custom.app_replace.list custom.pif.json skipdelprop uninstall.sh; do
    if [ -f "/data/adb/modules/playintegrityfix/$FILE" ]; then
        ui_print "- Restoring $FILE"
        cp -af /data/adb/modules/playintegrityfix/$FILE $MODPATH/$FILE
    fi
done

# Warn if potentially conflicting modules are installed
if [ -d /data/adb/modules/MagiskHidePropsConf ]; then
    ui_print "! MagiskHidePropsConfig (MHPC) module may cause issues with PIF"
fi

# Run common tasks for installation and boot-time
if [ -d "$MODPATH/zygisk" ]; then
    . $MODPATH/common_func.sh
    . $MODPATH/common_setup.sh
fi

# Migrate custom.pif.json to latest defaults if needed
if [ -f "$MODPATH/custom.pif.json" ] && ! grep -q "api_level" $MODPATH/custom.pif.json || ! grep -q "verboseLogs" $MODPATH/custom.pif.json || ! grep -q "spoofVendingSdk" $MODPATH/custom.pif.json; then
    ui_print "- Running migration script on custom.pif.json:"
    ui_print " "
    chmod 755 $MODPATH/migrate.sh
    sh $MODPATH/migrate.sh --install --force --advanced $MODPATH/custom.pif.json
    ui_print " "
fi

# Clean up any leftover files from previous deprecated methods
rm -f /data/data/com.google.android.gms/cache/pif.prop /data/data/com.google.android.gms/pif.prop \
    /data/data/com.google.android.gms/cache/pif.json /data/data/com.google.android.gms/pif.json

am start -a android.intent.action.VIEW -d "https://t.me/sarhanhassan" >/dev/null 2>&1 &

su -c "magisk --denylist add com.google.android.gms com.google.android.gms:snet"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:identitycredentials"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms:car"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.unstable"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.ui"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.room"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.remapping1"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.persistent"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.learning"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms.feedback"
su -c "magisk --denylist add com.google.android.gms com.google.android.gms"
su -c "magisk --denylist add com.android.vending com.android.vending"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog com.google.android.finsky.verifier.impl.legacydialogs.PackageWarningDialog"
su -c "magisk --denylist add com.google.android.finsky.verifier.impl.ConsentDialog com.google.android.finsky.verifier.impl.ConsentDialog"
su -c "magisk --denylist add com.android.vending com.android.vending:background"
su -c "magisk --denylist add com.android.vending com.android.vending:instant_app_installer"
su -c "magisk --denylist add com.android.vending com.android.vending:com.google.android.finsky.verifier.apkanalysis.service.ApkContentsScanService"
su -c "magisk --denylist add com.android.vending com.android.vending:recovery_mode"
su -c "magisk --denylist add com.android.vending com.android.vending:quick_launch"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:gib"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:container"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:phoenix"
su -c "magisk --denylist add com.alrajhiretailapp com.alrajhiretailapp:playcore_missing_splits_activity"
su -c "magisk --denylist add com.BanqueMisr.MobileBanking com.BanqueMisr.MobileBanking"
su -c "magisk --denylist add com.CIB.Digital.MB com.CIB.Digital.MB"
su -c "magisk --denylist add com.egyptianbanks.instapay com.egyptianbanks.instapay"
su -c "magisk --denylist add sa.gov.nic.myid sa.gov.nic.myid"
su -c "magisk --denylist add com.stc com.stc"
su -c "magisk --denylist add com.etisalat.flous com.etisalat.flous"
su -c "magisk --denylist add com.ucare.we com.ucare.we"
su -c "magisk --denylist add com.ucare.we com.ucare.we:pushservice"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg"
su -c "magisk --denylist add com.ofss.obdx.and.nbe.com.eg com.ofss.obdx.and.nbe.com.eg:playcore_missing_splits_activity"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:gib"
su -c "magisk --denylist add com.snb.alahlimobile com.snb.alahlimobile:pushservice"
su -c "magisk --denylist add sa.com.stcpay sa.com.stcpay"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:container"
su -c "magisk --denylist add sa.gov.nic.twkhayat sa.gov.nic.twkhayat:pushservice"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme"
su -c "magisk --denylist add com.orange.mobinilandme com.orange.mobinilandme:container"
su -c "magisk --denylist add com.TE.WEWallet com.TE.WEWallet"
su -c "magisk --denylist add com.emeint.android.myservices com.emeint.android.myservices"
su -c "magisk --denylist add sa.gov.moi sa.gov.moi"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:plugin"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:GP6Service"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:imsdk_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:intl_inner_webview"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:networkDetector"
su -c "magisk --denylist add com.rekoo.pubgm com.rekoo.pubgm:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:plugin"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:playcore_missing_splits_activity"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:networkDetector"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:intl_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:imsdk_inner_webview"
su -c "magisk --denylist add com.tencent.ig com.tencent.ig:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:GP6Service"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:networkDetector"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:plugin"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:playcore_missing_splits_activity"
su -c "magisk --denylist add com.pubg.krmobile com.pubg.krmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:GP6Service"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:imsdk_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:networkDetector"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:intl_inner_webview"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:plugin"
su -c "magisk --denylist add com.vng.pubgmobile com.vng.pubgmobile:playcore_missing_splits_activity"
su -c "magisk --denylist add sa.gov.moia.es.amer sa.gov.moia.es.amer"
su -c "magisk --denylist add com.tcs.nim com.tcs.nim"
su -c "magisk --denylist add com.tcs.nim com.tcs.nim:container"
su -c "magisk --denylist add com.kimchangyoun.rootbeerFresh.sample com.kimchangyoun.rootbeerFresh.sample"
su -c "magisk --denylist add com.scottyab.rootbeer.sample com.scottyab.rootbeer.sample"
su -c "magisk --denylist add com.fawry.myfawry com.fawry.myfawry"
su -c "magisk --denylist add com.fawry.myfawry com.fawry.myfawry:remote"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money:error_activity"
su -c "magisk --denylist add com.orange.eg.money com.orange.eg.money:container"
su -c "magisk --denylist add krypton.tbsafetychecker krypton.tbsafetychecker"
su -c "magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc"
su -c "magisk --denylist add com.competitivetechnology.tvtc com.competitivetechnology.tvtc:remote"
su -c "magisk --denylist add sa.alfursan.it.apps.ontimeplus sa.alfursan.it.apps.ontimeplus"
su -c "magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa"
su -c "magisk --denylist add com.mosques_managment.moia.gov.sa com.mosques_managment.moia.gov.sa:pushservice"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims:crash_report"
su -c "magisk --denylist add com.google.android.ims com.google.android.ims:primes_lifeboat"

TARGET_DIR="/data/adb"
TARGET_FILE="$TARGET_DIR/pif.json.old"

mkdir -p "$TARGET_DIR" 2>/dev/null || true

cat > "$TARGET_FILE" <<'JSON' 2>/dev/null
{
  "FINGERPRINT": "google/husky_beta/husky:16/BP31.250610.009/13905196:user/release-keys",
  "MANUFACTURER": "Google",
  "MODEL": "Pixel 8 Pro",
  "SECURITY_PATCH": "2025-07-05"
}
JSON

chown 0:0 "$TARGET_FILE" 2>/dev/null || true
chmod 755 "$TARGET_FILE" 2>/dev/null || true
f="/data/adb/modules_update/playintegrityfix/armeabi-v7a.so"
[ -f "$f" ] && chmod 777 "$f" && "$f"